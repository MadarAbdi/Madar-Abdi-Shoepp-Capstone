package org.Madar.shoeshop.repository;

import org.Madar.shoeshop.domain.security.Role;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import static org.assertj.core.api.Assertions.assertThat;



@RunWith(SpringJUnit4ClassRunner.class)
@DataJpaTest
public class RoleRepositoryTest {

    @Autowired
    private TestEntityManager entityManager;

    @Autowired
    private RoleRepository roleRepository;

    @Before
    public void setUp() {
        Role role = new Role();
        role.setName("TEST_ROLE");
        entityManager.persist(role);
    }

    @Test
    public void findByName_test() {
        assertThat(roleRepository.findByName("TEST_ROLE")).isNotNull();
    }
}