package org.Madar.shoeshop.repository;

import org.Madar.shoeshop.domain.*;
import org.Madar.shoeshop.domain.security.Role;
import org.Madar.shoeshop.domain.security.UserRole;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import utility.SecurityUtility;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.*;

import static org.assertj.core.api.Assertions.assertThat;


@RunWith(SpringJUnit4ClassRunner.class)
@DataJpaTest
public class OrderRepositoryTest {

    @Autowired
    private TestEntityManager entityManager;

    @Autowired
    private RoleRepository roleRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private OrderRepository orderRepository;
    User user = null;

    @Before
    public void setUp() {
        this.user = new User();
        this.user.setUsername("testuser");
        this.user.setPassword(SecurityUtility.passwordEncoder().encode("testuser"));
        this.user.setEmail("test@test.com");
        Set<UserRole> userRoles = new HashSet<>();
        for (String rolename : Arrays.asList("ROLE_USER")) {
            Role role = roleRepository.findByName(rolename);
            if (role == null) {
                role = new Role();
                role.setName(rolename);
                roleRepository.save(role);
            }
            userRoles.add(new UserRole(this.user, role));
        }
        this.user.setUserRoles(userRoles);
        this.user = entityManager.persist(this.user);

        Order order = new Order();
        order.setUser(this.user);
        order.setOrderTotal(BigDecimal.valueOf(100.0));
        LocalDate today = LocalDate.now();
        LocalDate estimatedDeliveryDate = today.plusDays(5);
        order.setOrderDate(Date.from(today.atStartOfDay(ZoneId.systemDefault()).toInstant()));
        order.setShippingDate(Date.from(estimatedDeliveryDate.atStartOfDay(ZoneId.systemDefault()).toInstant()));
        order.setOrderStatus("In Progress");
        order = entityManager.persist(order);
    }

    @Test
    public void findByUser_test() {
        User user = userRepository.findByEmail("test@test.com");
        assertThat(orderRepository.findByUser(user)).isNotNull();
    }
}