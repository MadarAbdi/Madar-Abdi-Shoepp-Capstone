package org.Madar.shoeshop;

import org.Madar.shoeshop.repository.*;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({
        ArticleRepositoryTest.class,
        OrderRepositoryTest.class,
        RoleRepositoryTest.class,
        UserRepositoryTest.class,
})
public class AppTestSuite {
}
