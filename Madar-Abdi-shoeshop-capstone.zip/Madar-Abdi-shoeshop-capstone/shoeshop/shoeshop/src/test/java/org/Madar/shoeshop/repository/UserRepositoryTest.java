package org.Madar.shoeshop.repository;

import org.Madar.shoeshop.domain.User;
import org.Madar.shoeshop.domain.security.Role;
import org.Madar.shoeshop.domain.security.UserRole;
import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import utility.SecurityUtility;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import static org.assertj.core.api.Assertions.assertThat;


@RunWith(SpringJUnit4ClassRunner.class)
@DataJpaTest
public class UserRepositoryTest {
    @Autowired
    private TestEntityManager entityManager;

    @Autowired
    private UserRepository userRepository;
    @Autowired
    private RoleRepository roleRepository;

    @Before
    public void setUp() {
        User user = new User();
        user.setUsername("testuser");
        user.setPassword(SecurityUtility.passwordEncoder().encode("testuser"));
        user.setEmail("test@test.com");
        Set<UserRole> userRoles = new HashSet<>();
        for (String rolename : Arrays.asList("ROLE_USER")) {
            Role role = roleRepository.findByName(rolename);
            if (role == null) {
                role = new Role();
                role.setName(rolename);
                roleRepository.save(role);
            }
            userRoles.add(new UserRole(user, role));
        }
        user.setUserRoles(userRoles);
        entityManager.persist(user);
    }

    @Test
    public void findByUsername_test() {
        assertThat(userRepository.findByUsername("testuser")).isNotNull();
    }

    @Test
    public void findByEmail_test() {
        assertThat(userRepository.findByEmail("test@test.com")).isNotNull();
    }
}