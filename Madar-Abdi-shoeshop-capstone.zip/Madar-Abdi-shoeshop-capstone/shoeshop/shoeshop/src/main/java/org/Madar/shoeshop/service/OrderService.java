package org.Madar.shoeshop.service;

import java.util.List;

import org.Madar.shoeshop.domain.Order;
import org.Madar.shoeshop.domain.Payment;
import org.Madar.shoeshop.domain.Shipping;
import org.Madar.shoeshop.domain.ShoppingCart;
import org.Madar.shoeshop.domain.User;

public interface OrderService {

	Order createOrder(ShoppingCart shoppingCart, Shipping shippingAddress, Payment payment, User user);
	
	List<Order> findByUser(User user);
	
	Order findOrderWithDetails(Long id);
}
