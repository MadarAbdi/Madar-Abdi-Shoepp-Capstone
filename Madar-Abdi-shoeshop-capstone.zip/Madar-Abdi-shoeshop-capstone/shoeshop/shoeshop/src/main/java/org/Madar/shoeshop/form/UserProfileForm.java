package org.Madar.shoeshop.form;


public class UserProfileForm {

}
