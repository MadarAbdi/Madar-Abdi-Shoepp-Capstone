package org.Madar.shoeshop;

import java.util.Arrays;

import org.Madar.shoeshop.service.UserService;
import org.Madar.shoeshop.service.impl.UserSecurityService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

@Component
public class StoreAppStartupRunner implements CommandLineRunner{

	@Autowired
	private UserService userService;
	
	@Override
	public void run(String... args) throws Exception {
		userService.createUser("admin","admin", "admin@admin.com", Arrays.asList("ROLE_USER", "ROLE_ADMIN"));
		userService.createUser("abc","def", "abc@admin.com",Arrays.asList("ROLE_USER", "ROLE_ADMIN"));
		userService.createUser("Madar","123456789", "Madar.Jamal1@gmail.com",Arrays.asList("ROLE_USER", "ROLE_ADMIN"));
	}
}

