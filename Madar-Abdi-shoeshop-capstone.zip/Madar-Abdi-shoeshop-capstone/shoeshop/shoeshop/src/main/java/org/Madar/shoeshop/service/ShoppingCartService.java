package org.Madar.shoeshop.service;

import org.Madar.shoeshop.domain.Article;
import org.Madar.shoeshop.domain.CartItem;
import org.Madar.shoeshop.domain.ShoppingCart;
import org.Madar.shoeshop.domain.User;

public interface ShoppingCartService {

	ShoppingCart getShoppingCart(User user);
	
	int getItemsNumber(User user);
	
	CartItem findCartItemById(Long cartItemId);
	
	CartItem addArticleToShoppingCart(Article article, User user, int qty, String size);
		
	void clearShoppingCart(User user);
	
	void updateCartItem(CartItem cartItem, Integer qty);

	void removeCartItem(CartItem cartItem);
	
}
