package org.Madar.shoeshop.domain;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class ArticleBuilder {
		
	private String title;
	private int stock;	
	private double price;
	private String picture;
	private List<String> sizes;
	private List<String> categories;
	private List<String> brands;
	
	public ArticleBuilder() {
	}

	/***
	 *
	 * @param title  - article title
	 * @return  current article builder object
	 */
	public ArticleBuilder withTitle(String title) {
		this.title = title;
		return this;
	}

	/***
	 *
	 * @param stock - current available stock
	 * @return current article builder object
	 */
	public ArticleBuilder stockAvailable(int stock) {
		this.stock = stock;
		return this;
	}

	/***
	 *
	 * @param price - article price
	 * @return current article builder object
	 */
	public ArticleBuilder withPrice(double price) {
		this.price = price;
		return this;
	}

	/***
	 *
	 * @param picture - article image url
	 * @return current article builder object
	 */
	public ArticleBuilder imageLink(String picture) {
		this.picture = picture;
		return this;
	}

	/***
	 *
	 * @param sizes - article sizes
	 * @return current article builder object
	 */
	public ArticleBuilder sizesAvailable(List<String> sizes) {
		this.sizes = sizes;
		return this;
	}

	/**
	 *
	 * @param categories - list of article categories
	 * @return current article builder object
	 */
	public ArticleBuilder ofCategories(List<String> categories) {
		this.categories = categories;
		return this;
	}

	/**
	 *
	 * @param brands - list of article brands
	 * @return current article builder object
	 */
	public ArticleBuilder ofBrand(List<String> brands) {
		this.brands = brands;
		return this;
	}

	/**
	 *
	 * @return build will create final instance of article
	 */
	public Article build() {
		Article article = new Article();
		article.setTitle(this.title);
		article.setPrice(this.price);
		article.setStock(this.stock);
		article.setPicture(this.picture);		
		
		if (this.sizes != null && !this.sizes.isEmpty()) {
			Set<Size> sizeElements = new HashSet<>();
			for (String val : this.sizes) {
				sizeElements.add(new Size(val,article));
			}	
			article.setSizes(sizeElements);
		}
		
		if (this.categories != null && !this.categories.isEmpty() ) {
			Set<Category> catElements = new HashSet<>();
			for (String val : this.categories) {
				catElements.add(new Category(val,article));
			}
			article.setCategories(catElements);
		}		
		if (this.brands != null && !this.brands.isEmpty() ) {
			Set<Brand> brandlements = new HashSet<>();
			for (String val : this.brands) {
				brandlements.add(new Brand(val,article));
			}
			article.setBrands(brandlements);
		}		
		
		
		return article;
	}
	
}